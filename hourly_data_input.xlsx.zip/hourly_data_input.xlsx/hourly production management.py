import pandas as pd
import plotly.express as px
import mysql.connector

# === CONFIGURATION ===
USE_SQL = False  # Change to True if you're using MySQL, otherwise it will load from Excel
SQL_PASSWORD = "your_password"  # Change this if you use SQL
EXCEL_INPUT_PATH = C:\Users\vikas\AppData\Local\Programs\Python\Python312\hourly_data_input.xlsx 
EXCEL_OUTPUT_PATH = "hourly_data_processed.xlsx"

# === STEP 1: Load Data ===
if USE_SQL:
    # MySQL connection
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password=SQL_PASSWORD,
        database="production_db"
    )

    query = """
    SELECT 
        mp.MachineID, 
        mp.Hour, 
        mp.TargetOutput, 
        mp.ActualOutput,
        mp.CumulativeOutput, 
        mp.Defects, 
        mp.DowntimeMinutes,
        sd.Date,
        sd.Shift,
        mp.OperatorName,
        mp.ProductName,
        mp.DowntimeReason,
        mp.OperatorRemarks
    FROM MachineProduction mp
    JOIN ShiftDetails sd ON mp.ShiftID = sd.ShiftID
    WHERE sd.Date = '2025-04-21' AND sd.Shift = 'Morning';
    """

    df = pd.read_sql(query, conn)
    conn.close()
else:
    df = pd.read_excel(EXCEL_INPUT_PATH)

# === STEP 2: Process Metrics ===
df['Efficiency (%)'] = (df['ActualOutput'] / df['TargetOutput'].replace(0, 1)) * 100
df['Defect Rate (%)'] = (df['Defects'] / df['ActualOutput'].replace(0, 1)) * 100
df['Downtime Impact (%)'] = (df['DowntimeMinutes'] / 60) * 100

# === STEP 3: Export Processed Data to Excel (for Power BI) ===
df.to_excel(EXCEL_OUTPUT_PATH, index=False)
print(f"✅ Processed Excel saved to: {EXCEL_OUTPUT_PATH}")

# === STEP 4: (Optional) Preview Visuals in Python ===
fig1 = px.line(df, x='Hour', y='Efficiency (%)', color='MachineID', title='Hourly Efficiency', markers=True)
fig2 = px.bar(df, x='Hour', y='Defect Rate (%)', color='MachineID', title='Defect Rate by Hour')
fig3 = px.line(df, x='Hour', y='Downtime Impact (%)', color='MachineID', title='Downtime Impact', markers=True)

# Show plots (optional)
fig1.show()
fig2.show()
fig3.show()

